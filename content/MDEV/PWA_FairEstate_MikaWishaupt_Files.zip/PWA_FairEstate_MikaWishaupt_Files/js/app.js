//Sources:
// Map live server: https://www.youtube.com/watch?v=NyjMmNCtKf4&t=863s
// A tutorial that helped me with making a funtional map with an open source map.

// camera - notifications - sharing: Avans Brightspace
// Notifications and camera: https://brightspace.avans.nl/d2l/le/lessons/152123/topics/1128012
// sharing: https://brightspace.avans.nl/d2l/le/lessons/152123/topics/1125244
// Camera - notification and sharing are based on the recources of Brightspace and implemented with code adaptations to serve my PWA.
// The camera function is mostly unadapted with added and changed commentary, additional code for my PWA like only run on camera.html

// Overal use: ChatGpt (used for bug fixing and assistance with doubtness)
// The used resources are there to help me with the PWA and to learn from and adapt code.


if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js')
    .then((reg) => console.log('service worker registered!', reg)) //service worker is working on browser!
    .catch((err) => console.log('service worker not registered!', err)); //service worker is not working
}


// Notifications:

if (window.location.pathname.includes('index.html')) {  //I want it to only show on the index.html

  //Check if notifications are supported by current browser
  if ("Notification" in window) {
    //If so, display the notification button
    document.querySelector(".btnEnableNotifications");
    //Make an eventlistener for the click to enable notifications
    document.querySelector(".btnEnableNotifications").addEventListener("click", askForNotificationPermission);
  }

  function displayFirstNotification() {
    //If we display our first notification remove the button on the page
    document.querySelector(".btnEnableNotifications").style.display = "none";

    if ("Notification" in window && Notification.permission === "granted") { //Does browser support it and what happens if it's granted
      //How notification is displayed
      let options = {
        //Text that will be displayed with the notifications
        body: "You are successfully subscribed to Fair Estate notifications! Thank you very much!",
        //icon of the notification that is displayed. In this case the Fair Estate icon
        icon: "../img/icons/icon-192x192.png",

      };
      //display notification
      new Notification("subscription success!", options);
    }
  }

  //A function that makes a promt to ask the user to allow notifications
  function askForNotificationPermission() {
    //Request the permission to the user
    Notification.requestPermission(function (result) {
      //Log the result of the permission to see whats inside of it
      console.log("user Choice", result);
      //Test if the permission is granted and if it is granted display the first notification|
      //This is mostly for the developers to see
      if (result != "granted") {
        console.log("No permission granted"); //send to the console that there is no permission
      } else {
        console.log("Permission granted!!! NOTIFICATION TOEGESTAAN"); // send to the console that there is permission
        displayFirstNotification();
      }
    });
  }

  //In the next part is the code that hides the button if you allow notifications

  // Check for Notification Support and permission on page load
  document.addEventListener('DOMContentLoaded', function () {
    if ("Notification" in window) { //check for notification
      if (Notification.permission === "granted") {
        // If notifications are already allowed, hide the button
        document.querySelector(".btnEnableNotifications").style.display = "none"; //Display none means that the class with the queryselector is not displayed on the html page
      } else {
        // If notifications are not granted or denied, display the button and add event listener
        document.querySelector(".btnEnableNotifications").style.display = "block"; //the benenablenotificaitons class will be displayed as a block-level element.
        document.querySelector(".btnEnableNotifications").addEventListener("click", askForNotificationPermission); //click function on the add eventlistener.
      }
    } else {
      console.log("Notifications not supported");
    }
  });
}


if (window.location.pathname.includes('camera.html')) {  //Runs the code only on the camera.html page


  window.onload = function () {
    document.getElementById("pickImage").style.display = "none"; //Ensure that the pickImage is hidden on reloading page and only opens when you click on pick an image.
  };

  //For convenience i kept the ID names
  //Eventlistener on an id that starts streaming with click.
  document.getElementById("selfieBtn").addEventListener("click", startVideo);
  //Eventlistener on an id that starts capturing camera on click.
  document.getElementById("captureBtn").addEventListener("click", captureImage);
  //Eventlistener Option to get an image instead of using the camera with click.
  document.getElementById("pickImgBtn").addEventListener("click", pickImage);
  //Eventlistener to detect changes when you want a new image.
  document
    .getElementById("imagePicker") //get id imagePicker
    .addEventListener("change", captureImagePick); //changes the image

  //Variabele called videoPlaer
  let videoPlayer;

  //Variable image tag
  let img = document.querySelector("#imgCaptured");

  //Create a function for displaying camera video streaming.
  function startVideo() {
    //check if the camera or other mediadevices are working for the browser and if so the code will continue else there is an error.
    if ("mediaDevices" in navigator) {
      navigator.mediaDevices
        .getUserMedia({ video: true }) 
        //if it's true and the promise is fulfilled and now the streaming function is enabled.
        .then(function (stream) {
          //The user has to accept the camera usage else it won't work
          //The video will play on the id player.
          videoPlayer = document.querySelector("#player");
          //place the stream of the camera into the src object of the video container in the html.
          videoPlayer.srcObject = stream; // stream is called videoPlayer.srcObject
          //Display the container surrounding the video element
          document.getElementById("divSelfie").style.display = "block"; //Display divSelfie as a block element.
        })
        //Get the error if it will not work and the alternative option is to pick an image from your phone or pc.
        .catch(function (error) {
          //Errors will come here
          console.log("There was an error with the camera", error);
          //then show the image picker, because the camera doesn't work
          document.getElementById("pickImage").style.display = "none"; //pickImage wont be hidden.
        });
    }
  }

  //Create a function to capture a snapshot from the camera video stream
  function captureImage() {
    //Gather the videostream from the previous founded mediaDevices that are accepted.
    navigator.mediaDevices.getUserMedia({ video: true }).then(function (stream) {
      //Get the newest frame
      let mediaStreamTrack = stream.getVideoTracks()[0];
      //Mediastream will enter imagecapture constructor that starts at array 0
      let imageCapture = new ImageCapture(mediaStreamTrack);
      //use Takephoto method for one single image. Returns a promise that
      imageCapture
        .takePhoto()
        .then((blob) => {
          // Create a URL from the blob data received
          img.src = URL.createObjectURL(blob);
          // Once the image is loaded, revoke/release the created URL
          img.onload = () => { //loading Image
            URL.revokeObjectURL(img.src); 
          };
        })
        //Error is catched and in console the error displays that something went wrong with taking the picture.
        .catch((error) => console.error("takePhoto() error:", error));
    });
  }

  // Function to pick an image instead of capturing from the camera
  function pickImage() {
      // Stop streaming the camera if applicable
     // Show the input element for picking an image
    document.getElementById("pickImage").style.display = "block";
  }
  // Function to capture the selected image file or blob, for example, from your phone's gallery
  function captureImagePick(input) {
    //Filereader new instance
    let reader = new FileReader();
    //When a read is succesful handled change the src with a new image form the obtained data form the FileReader
    reader.onload = function (e) {
      img.src = "" + e.target.result + "";
    };
     // Read the selected file as a Data URL (representing the image as a URL)
    reader.readAsDataURL(input.target.files[0]);
  }

}


//SHARE


if (['camera.html', 'contact.html', 'location.html', 'watchers.html'].includes(window.location.pathname.split('/').pop())) { //Makes the code only checked on these pages and not on index.html since it doesnt have a sharebutton
  const shareButtonTop = document.querySelector('.shareButtonTop'); //Use classes for multiple buttons and not ID
  const shareButtonBottom = document.querySelector('.shareButtonBottom'); //Use classes for multiple buttons and not ID


  //Share button top
  if (navigator.share) {
    if (shareButtonTop) {
      shareButtonTop.addEventListener('click', async () => { //eventlistener on the click function. async makes sure that multiple taks can handle through each other and not in chronological order if one function doesnt work.
        try {
          await navigator.share({
            title: 'Fair Estate Share',  // The title you want to share
            text: 'The site to find your house!', // The text content you want to share
            url: 'https://fairEstate_example.com' // The URL you want to share
          });
          console.log('Shared successfully');
        } catch (error) {
          console.error('Error sharing:', error);
        }
      });
    }

    //Share button bottom
    if (shareButtonBottom) {
      shareButtonBottom.addEventListener('click', async () => {
        try {
          await navigator.share({
            title: 'Fair Estate Share',
            text: 'The site to find your house!',
            url: 'https://fairEstate_example.com'
          });
          console.log('Shared successfully');
        } catch (error) {
          console.error('Error sharing:', error);
        }
      });
    }
  } else {
    // If the sharebutton is not supported or working
    if (shareButton) {
      shareButton.style.display = 'none';
      console.log('Web Share API not supported');
    }
    if (shareButtonBottom) {
      shareButtonBottom.style.display = 'none';
      console.log('Web Share API not supported');
    }
  }
}

// MAP function
// PROBLEM. THE MAP WILL TAKE A LOT OF CACHE STORAGE.

if (window.location.pathname.includes('location.html')) {  // Makes the code only run on location.html Else it will look for stuff that is only on location.html and creates errors when missing.
  var map = L.map('map').setView([51.505, -0.09], 13); //prefix view

  // Get the map from openstreetmap
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
  }).addTo(map); //add to the var map

  navigator.geolocation.watchPosition(success, error);  //get user location

  let marker, circle;

  function success(pos) {

    const lat = pos.coords.latitude; //latitude
    const lng = pos.coords.longitude;//longitude
    const accuracy = pos.coords.accuracy;//accuracy

    //Deletes a marker if you change location.
    if (marker) {
      map.removeLayer(marker);
      map.removeLayer(circle);
    }

    marker = L.marker([lat, lng]).addTo(map);
    circle = L.circle([lat, lng], { radius: accuracy }).addTo(map); //circle radius. Circle might be bigger when you have a high latitute like on a mountain.

    map.fitBounds(circle.getBounds()); //show location from the start

  }
  //error handling if there is issues with location sharing or the user denies request.
  function error(err) {
    if (err.code === 1) {
      alert("Please allow geolocation");
    } else {
      alert("Cannot get location");
    }

  }
}