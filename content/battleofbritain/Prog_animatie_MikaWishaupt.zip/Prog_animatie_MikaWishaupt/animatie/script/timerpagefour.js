setTimeout(function(){
    window.location.href = 'pagefive.html';
 }, 30000);
// deze javascript code was gemaakt zodat die alleen werkt op pagina vier en niet op alle andere.
