gsap.registerPlugin(MotionPathPlugin); // registreer plugin die ik gebruikte voor de motionpath




// pagina 2



// wolk animatie in gsap gemaakt om van te leren.
var wolkpagina2 = document.querySelector('.wolkpagina2'); // geef de locatie een naam
var wolktijdpagina2 = new TimelineMax({ //Geef de tijd een naam
  repeat: -1 //animatie moet oneindig doorgaan.
});
wolktijdpagina2.add(TweenMax.to(wolkpagina2, 20, { //de 20 staat voor snelheid              //tweenmax is een oudere methode van gsap die ik online had geleerd. https://greensock.com/docs/v2/TweenMax
  x: 200, //de locatie waar de wolk naartoe gaat
  ease: Power0.easeNone //de standaard ease verwijderd omdat als je niks aangeeft dan verloomt die.
})); //door geen ease te gebruiken haal je de standaard ease weg die zorgt dat je animatie afremt.
wolktijdpagina2.add(TweenMax.to(wolkpagina2, 20, { //de 20 staat voor de snelheid
  x: 0, //terug naar startlocatie gaan
  ease: Power0.easeNone //weer de ease verwijderen
}));



//De knop moet afgaan

$('.knoppaginatwee').click(function() { //Je klikt op de class van de knop
  window.location.href = 'pagethree.html'; //de knop heeft als eindbestemming de derde pagina.  Ik wilde variatie en ook zonder html buttons werken.
})


// pagina 3


// wolk animatie
//Zelfde principe als de eerste wolk alleen de snelheid, welke wolk en locatie is veranderd.
var wolkpagina3 = document.querySelector('.wolkpagina3');
var wolktijdpagina3 = new TimelineMax({
  repeat: -1
});
wolktijdpagina3.add(TweenMax.to(wolkpagina3, 40, {
  x: 800,
  ease: Power0.easeNone
})); //door geen ease te gebruiken haal je de standaard ease weg die zorgt dat je animatie afremt.
wolktijdpagina3.add(TweenMax.to(wolkpagina3, 40, {
  x: 0,
  ease: Power0.easeNone
}));





gsap.to(".straaljagerpagina3", { //selecteert de straaljager
  duration: 5, //hoe lang duurt de animatie
  delay: 9, //wanneer moet de animatie starten

  motionPath: {
    path: "#pathstraaljagerpagina3", //de path die in de html staat wordt hier geselecteerd en word verbonden.
    autoRotate: true //autoRotate houdt in dat de straaljager meebeweegt met rotatie.

  }
});

$(".straaljagerpagina3").delay(12000).fadeTo(500, 0); //Straaljager verwijnen zodat die niet buiten het scherm in beeld is voor lange tijd.



$('.verderknoppagina3').click(function() { //zelfde idee als eerder maar nu gaat een andere knop naar pagina 4.
  window.location.href = 'pagefour.html';
})

// pagina 4

gsap.to(".raket", {        //selecteert de raket.

  duration: 7, //hoe lang duurt de animatie.
  delay: 18, //wanneer moet de animatie starten

  motionPath: {
    path: "#pathraket",  //de path die in de html staat wordt hier geselecteerd en word verbonden.
    autoRotate: true //autoRotate houdt in dat de straaljager meebeweegt met rotatie.

  }
});



// pagina 5

$('.verderknoppagina5').click(function() { //knop naar de laatte pagina.
  window.location.href = 'pagesix.html';
})
