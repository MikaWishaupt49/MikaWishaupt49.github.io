// Sources:
// Serviceworker is made with help of Net Ninja  Link: https://www.youtube.com/watch?v=4XT23X0Fjfk&list=PL4cUxeGkcC9gTxqJBcDmoi5Q2pzDusSL7
// Net Ninja explained how a service worker works, how you can make caches and store stuff and I implemented it for my PWA.


"use strict"; // Gives the service worker strict rules to work on for reliability and maintainability.

//Do not put the service worken in a folder! 
//It needs to see all the content of the app

const staticCacheName = 'site-static-v1' //static cache (stores mostly not changing elements like images and html pages)
const dynamicCache = 'site-dynamic-v1' //Dynamic cache (stores adaptive elements like the map)
const cacheAssets = [
    '/',  //Store requist url's
    '/index.html',
    '/pages/camera.html',
    '/pages/contact.html',
    '/pages/location.html',
    '/pages/watchers.html',
    '/js/app.js',
    '/js/ui.js',
    '/js/materialize.min.js',
    '/css/styles.css',
    '/css/materialize.min.css',
    '/img/icons/icon-16x16.png',
    '/img/icons/icon-32x32.png',
    '/img/icons/icon-48x48.png',
    '/img/icons/icon-128x128.png',
    '/img/icons/icon-144x144.png',
    '/img/icons/icon-192x192.png',
    '/img/icons/icon-512x512.png',
    '/img/BackButton.png',
    '/img/CameraIconWithoutText.png',
    '/img/CameraIconWithText.png',
    '/img/ContactIconWithoutText.png',
    '/img/ContactIconWithText.png',
    '/img/HouseDesktoplogo5.png',
    '/img/HousePhoneLogo-01.png',
    '/img/LocationIconWithoutText.png',
    '/img/LocationIconWithText.png',
    '/img/MenuBarIconForDesktop.png',
    '/img/ScreenshotRicher.png',
    '/img/ScreenshotRicherMobile.png',
    '/img/ShareIconWithoutText.png',
    '/img/ShareIconWithText.png',
    '/img/WatcherImage1.png',
    '/img/WatcherImage2.png',
    '/img/WatcherImage3.png',
    '/img/WatchersWithoutText.png',
    '/img/WatchersWithText.png',

    //!!! Important instead of /img you do ../img because the html pages are in a folder
    //Check cache in f12
    //check cache storage and the saved service worker for what is stored.
];


//Cache size limit function

//It would be nice to not use too many recources for a PWA.
//The map function takes a lot of storage unsolved issue
const limitCacheSize = (cacheName, size) => {
    caches.open(cacheName).then(cache => {
        //Retrieve the keys
        cache.keys().then(keys => {
            //Will the number of keys exceed the specified size?
            if (keys.length > size) {
                // if the size of the keys exceed the limit, the oldest will be deleted.
                cache.delete(keys[0]).then(() => {
                    //After deletion check the cache size again on repeat
                    limitCacheSize(cacheName, size); //check the limitCacheSize again if something else still needs to be deleted and deletes old things in the cache
                });
            }
        });
    });
};

//Service worker installation

self.addEventListener('install', evt => {
    console.log('service worker has been installed!'); //server is installed. pop up when you change or install it again.
    evt.waitUntil( //wait until this is done before installing the service worker.
        caches.open(staticCacheName).then(cache => {
            console.log('caching shell assets');
            return cache.addAll(cacheAssets);  //store the data you want for offline use.
        })
            .then(() => {
                limitCacheSize(staticCacheName, 50); //The size limit of the staticcache. In cache storage you can see the total entries. if you put it on 10 it will have a 10 as limit.
              
            })
    );
});

//listening activation service worker!

self.addEventListener('activate', evt => {
    //console.log('service worker has been activated!'); You can use this to check!
    evt.waitUntil(
        caches.keys().then(keys => {    //get all cache keys
            //console.log(keys); //show the names of the different caches made
            return Promise.all(keys
                .filter(key => key !== staticCacheName && key !== dynamicCache) //if the names are not equal to the static cache name and the dynamic cache on top it goes further 
                .map(key => caches.delete(key)) //deletes older caches that are not equal to the name on top.
            )
        })
    );
});


//fetch event
//Handles how netwowrk requests are handled


// Pages are stored when the user enters them. When the user goes offline, the user can still enter pages that were used.
self.addEventListener('fetch', evt => { //Register fetch
    //console.log('fetch event',evt);
    evt.respondWith( //Intercepts and handles fetch requests
        caches.match(evt.request).then(cacheRes => { //look for other pages when user is offline. 
            return cacheRes || fetch(evt.request).then(fetchRes => {  //check if there is something that matches the request that is in the cache
                return caches.open(dynamicCache).then(cache => {
                    cache.put(evt.request.url, fetchRes.clone()); //clone makes sure that cache can be stored but also clone an original request.
                    limitCacheSize(dynamicCache, 100); //dynamic cache limit
                    return fetchRes; //if there is a cache, else return to fetch

                })
            });
        })
    );
});